<?php $__env->startSection('content'); ?>
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2"><?php echo app('translator')->get('admin.dashboard'); ?></h1>        
        </div>
        <div class="row">
        <div class="col-md-4">
            <section class="admin admin-simple-sm pt-3 shadow-sm">
                <div class="admin-simple-sm-icon">
                    <i class="icon-file-earmark-text"></i>
                </div>
                <div class="admin-simple-sm-bottom"> <?php echo app('translator')->get('admin.totalpost'); ?> :
                <?php echo e($countPo); ?>

                </div>
                <div class="admin-simple-sm-bottom bottom-white">
                        <a href="<?php echo e(url('/contents/')); ?>" role="button" class="btn btn-secondary btn-sm"><?php echo app('translator')->get('admin.posts'); ?></a>
                </div>
            </section>
        </div>
        <div class="col-md-4">
            <section class="admin admin-simple-sm pt-3 shadow-sm">
                <div class="admin-simple-sm-icon">
                    <i class="icon-file-earmark-x"></i>
                </div>
                <div class="admin-simple-sm-bottom"><?php echo app('translator')->get('admin.unpublishedposts'); ?> :
                <?php if($countUn > 0): ?>                
                <span class="badge rounded-pill bg-danger"><?php echo e($countUn); ?></span>
                <?php else: ?>
                <?php echo e($countUn); ?>

                <?php endif; ?>
                </div>
                <div class="admin-simple-sm-bottom bottom-white">
                        <a href="<?php echo e(url('/unpublished/')); ?>" role="button" class="btn btn-secondary btn-sm"><?php echo app('translator')->get('admin.unpublishedposts'); ?></a>
                </div>
            </section>
        </div>
        <div class="col-md-4">
            <section class="admin admin-simple-sm pt-3 shadow-sm">
                <div class="admin-simple-sm-icon">
                    <i class="icon-file-earmark-person"></i>
                </div>
                <div class="admin-simple-sm-bottom"><?php echo app('translator')->get('admin.totalusers'); ?> :
                <?php echo e($countUs); ?>

                </div>
                <div class="admin-simple-sm-bottom bottom-white">
                        <a href="<?php echo e(url('/users/')); ?>" role="button" class="btn btn-secondary btn-sm"><?php echo app('translator')->get('admin.users'); ?></a>
                </div>
            </section>
        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/admin.blade.php ENDPATH**/ ?>