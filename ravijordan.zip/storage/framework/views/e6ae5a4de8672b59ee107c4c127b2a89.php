<tr>
    <td><input type="checkbox" name="multiple[]" class="checkboxes" value="<?php echo e($post->id); ?>" /></td>
    <td>
        <a href="<?php echo e(url('/posts/' . $post->post_slug)); ?>">
            <?php if(! empty($post->post_title)): ?>
            <?php echo e(str_limit($post->post_title, 35)); ?>

            <?php else: ?>
            Title not found!
            <?php endif; ?>
        </a>
    </td>
    <td><?php echo e(shortNumber($post->counter)); ?></td>
    <td><a href="<?php echo e(url('/profile/' . $post->user->username)); ?>"><?php echo e(str_limit($post->user->name, 10)); ?></a></td> 
    <td><a href="<?php echo e(url('/home/' . $post->id . '/edit')); ?>"><?php echo app('translator')->get('admin.edit'); ?></a></td>
    <td><a class="color-delete" href="<?php echo e(url('/home/' . $post->id)); ?>"><?php echo app('translator')->get('admin.delete'); ?></a></td>
</tr><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/posts/post.blade.php ENDPATH**/ ?>