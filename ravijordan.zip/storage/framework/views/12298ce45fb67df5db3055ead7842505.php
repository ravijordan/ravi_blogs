
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo app('translator')->get('admin.editpage'); ?></h1>  
    </div>
    <div class="box-white ms-3 me-3 shadow-sm">
        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form method="POST" action="<?php echo e(url('/pages/' . $page->id)); ?>" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>
            <div class="mb-3 row">
                <label for="page_title" class="col-sm-3 col-form-label"><?php echo app('translator')->get('admin.pagetitle'); ?></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="page_title" name="page_title" value="<?php echo e($page->page_title); ?>" required>
                    <small id="name" class="form-text text-muted"><?php echo app('translator')->get('admin.required'); ?></small>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="page_slug" class="col-sm-3 col-form-label"><?php echo app('translator')->get('admin.pageslug'); ?></label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="page_slug" name="page_slug" value="<?php echo e($page->page_slug); ?>" required>
                    <small id="name" class="form-text text-muted"><?php echo app('translator')->get('admin.required'); ?></small>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="page_content" class="col-sm-3 col-form-label"><?php echo app('translator')->get('admin.pagecontent'); ?></label>
                <div class="col-sm-9 myeditor">
                    <div id="pageeditor"><?php echo clean( $page->page_content ); ?></div>
                    <input class="txtcont" type="hidden" name="page_content">
                </div>
            </div>
            <div class="mb-3 row">
                <div class="offset-sm-3 col-sm-9">
                    <button onclick="ClickSave()" type="submit" class="btn btn-primary"><?php echo app('translator')->get('admin.update'); ?></button>
                    <a class="btn btn-danger" role="button" href="<?php echo e(url('pages')); ?>"> <?php echo app('translator')->get('admin.cancel'); ?> </a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
var toolbarOptions = [
      ['bold', 'italic', 'underline', 'strike'],
      ['blockquote', 'code-block', 'link', 'image'],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'color': [] }, { 'background': [] }],
      ['clean']
    ];
    
var Image = Quill.import('formats/image');
  Image.className = 'img-fluid';
  Quill.register(Image, true);

var quill = new Quill('#pageeditor', {
  theme: 'snow',
  modules: {
    toolbar: toolbarOptions
  },
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/pages/edit.blade.php ENDPATH**/ ?>