
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo app('translator')->get('admin.posts'); ?></h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a class="btn btn-success fw-bold" href="<?php echo e(url('/home/add/')); ?>" role="button"><?php echo app('translator')->get('admin.addnewpost'); ?></a>
        </div>    
    </div>
    <div class="row ms-3 me-3">
        <ul class="nav nav-pills">
            <li class="nav-item">
                <a class="nav-link active" href="<?php echo e(url('/contents/')); ?>"><?php echo app('translator')->get('admin.published'); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/unpublished/')); ?>"><?php echo app('translator')->get('admin.unpublished'); ?></a>
            </li>
        </ul>
    </div>  
    <div class="row box-white ms-3 me-3 mt-2 shadow-sm">                    
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col"><input type="checkbox" name="CheckAll" onclick="checkAll(this)" /></th>
                    <th scope="col"><?php echo app('translator')->get('admin.title'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('admin.views'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('admin.user'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('admin.edit'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('admin.delete'); ?></th>
                </tr>
            </thead>
            <form action="<?php echo e(url('/cnt/multiple/')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('POST')); ?>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>      
                <?php echo $__env->make('posts.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5>
                    <?php echo app('translator')->get('admin.nopostfound'); ?>
                </h5>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="d-grid gap-2 d-md-block ps-0">
                <button name="mulbtn"  type="submit" class="btn btn-danger btn-sm" value="Delete"><?php echo app('translator')->get('admin.delete'); ?></button>
                <button name="mulbtn"  type="submit" class="btn btn-secondary btn-sm ms-2" value="Unpublish"><?php echo app('translator')->get('admin.unpublish'); ?></button>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($posts->links()); ?>

        </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/posts/index.blade.php ENDPATH**/ ?>