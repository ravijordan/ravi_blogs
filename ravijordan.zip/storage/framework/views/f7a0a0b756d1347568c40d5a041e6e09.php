<!DOCTYPE html>
<html lang="en" class="<?php echo e($theme); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?php echo e(!empty($tag->desc) ? $tag->desc : $setting->site_desc); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">


		<meta property="fb:app_id" content="<?php echo env('FACEBOOK_API_ID'); ?>" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:type" content="article" />
        <meta property="og:title" content="<?php echo e($setting->site_name . ' - ' . $setting->site_title); ?>" />
        <meta property="og:description" content="<?php echo e(!empty($tag->desc) ? $tag->desc : $setting->site_desc); ?>" />
        <meta property="og:image" content="<?php echo e(url('/images/social.png')); ?>" />     
        <!-- Twitter card-->
        <meta name="twitter:card" content="summary_large_image" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:title" content="<?php echo e($setting->site_name . ' - ' . $setting->site_title); ?>" />
        <meta property="og:description" content="<?php echo e(!empty($tag->desc) ? $tag->desc : $setting->site_desc); ?>" />
        <meta name="og:image" content="<?php echo e(url('/images/social.png')); ?>" />

        <title><?php echo e($setting->site_name . ' - ' . $setting->site_title); ?></title>        
        <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/instant.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/instanticon/style.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('css'); ?>
        <?php if(!empty($setting->site_analytic)): ?>
            <?php echo $setting->site_analytic; ?>

        <?php endif; ?>
    </head>
    <?php echo $__env->yieldContent('bodyclass'); ?>

        <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('jumbotron'); ?>

        <?php if($flash = session('message')): ?>
        <div class="container mt-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <?php elseif($flash = session('error')): ?>
        <div class="container mt-3">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e($flash); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->yieldContent('extra'); ?>

        <?php if($setting->cookie_option == '0'): ?>
            <?php echo $__env->make('layouts.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="<?php echo e(asset('/js/main.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function(){
                document.getElementById('se-pre-con').style.visibility = 'hidden'; 
                var element = document.getElementById('maincontent');
                element.classList.remove('d-none');
            }, false);
        </script>
    </body>
</html><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/layouts/master.blade.php ENDPATH**/ ?>