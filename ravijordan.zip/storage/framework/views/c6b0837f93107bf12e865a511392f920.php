
<?php $__env->startSection('bodyclass'); ?>
    <body class="d-flex flex-column h-100">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
<div class="header">
    <img class="header-img-top" src="<?php echo e(url('/uploads/'. $user->cover)); ?>" alt="<?php echo e($user->name); ?>">
    <div class="container-fluid">
        <div class="header-body mt-n6">
            <?php echo $__env->make('public.profilehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row align-items-center">
                <div class="col">
                    <ul class="nav nav-justified">
                      <li class="nav-item nav-pro">
                        <a class="nav-link" aria-current="page" href="<?php echo e(url('/profile/' . $user->username)); ?>"><?php echo app('translator')->get('messages.new.posts'); ?></a>
                      </li>
                      <li class="nav-item nav-pro">
                        <a class="nav-link" href="<?php echo e(url('/followers/' . $user->username)); ?>"><?php echo app('translator')->get('messages.new.followers'); ?> <span class="badge bg-secondary"><?php echo e(shortNumber($user->followers()->count())); ?></span></a>
                      </li>
                      <li class="nav-item nav-pro">
                        <a class="nav-link active" href="<?php echo e(url('/following/' . $user->username)); ?>"><?php echo app('translator')->get('messages.new.following'); ?> <span class="badge bg-secondary"><?php echo e(shortNumber($user->follows()->count())); ?></span></a>
                      </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-2">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4">
            <div class="d-flex alert follow-card border-one">
                <?php if(substr( $follower->avatar, 0, 4 ) === "http"): ?>
                <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e($follower->avatar); ?>">
                <?php else: ?>
                <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e(url('/images/' . $follower->avatar)); ?>">
                <?php endif; ?>
            <div class="ps-2 mb-0 small lh-sm w-100">
                <div class="flwid d-flex justify-content-between">
                    <div>
                      <strong class="text-gray-dark"><a href="<?php echo e(url('/profile/' . $follower->username)); ?>"><?php echo e($follower->name); ?></a></strong>
                      <span class="d-block"><?php echo e($follower->username); ?></span>
                    </div>
                    <input type="hidden" name="follow_id" value="<?php echo e($follower->id); ?>">
                    <?php if(auth()->check()): ?>
                        <?php if (! (auth()->id() == $follower->id)): ?>
                            <?php if(auth()->user()->following($follower)): ?>
                            <button type="button" class="btn btn-sm btn-secondary border-one" onclick="follow(this)"><?php echo app('translator')->get('messages.new.unfollow'); ?></button>
                            <?php else: ?>
                            <button type="button" class="btn btn-sm btn-dark border-one" onclick="follow(this)"><?php echo app('translator')->get('messages.new.follow'); ?></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>                
              </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-md-12">
            <h5><?php echo app('translator')->get('messages.new.nofollowing'); ?></h5>
        </div>
        <?php endif; ?>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<div class="container-fluid mt-auto">
    <hr>
    <div class="row">
        <div class="col-md-12">
        <?php echo e($follows->links()); ?>

        </div>
    </div>
<footer class="blog-footer">
<?php if(count($pages) > 0): ?>
    <ul class="list-inline">
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
       <li class="list-inline-item">
            <a class="text-mode" href="<?php echo e(url('/page/' . $page->page_slug)); ?>"><?php echo e($page->page_title); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php if(!empty($setting->footer)): ?>
<div class="text-muted"><?php echo clean($setting->footer); ?></div>
<?php endif; ?>
</footer>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    var followURL = "<?php echo e(url('/follow')); ?>";
    var followtxt = "<?php echo app('translator')->get('messages.new.follow'); ?>";
    var unfollowtxt = "<?php echo app('translator')->get('messages.new.unfollow'); ?>";
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/following.blade.php ENDPATH**/ ?>