
<?php $__env->startSection('bodyclass'); ?>
    <body class="d-flex flex-column h-100">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="se-pre-con" class="d-flex justify-content-center align-items-center">
    <div class="spinner-grow me-1 text-danger" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
    <div class="spinner-grow me-1 text-warning" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
    <div class="spinner-grow me-1 text-info" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
</div>
<div id="maincontent" class="container-fluid mt-5 d-none">
    <div class="row">
        <div class="grid" data-columns>
            <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="card border-one bg-dark text-white">
                <img class="tag-img" src="<?php echo e(url('/uploads/' . $tag->tag_media)); ?>" alt="<?php echo e($tag->name); ?>">
                <div class="card-img-overlay bg-over">
                    <a class="link-over" href="<?php echo e(url('/category/' . $tag->name)); ?>"></a>
                    <p class="card-text text-muted text-uppercase mb-0"><?php echo e(str_limit($tag->title, 70)); ?></p>
                    <h2 class="text-uppercase"> <?php echo e($tag->name); ?> </h2>   
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12">
                <h5 class="text-mode"><?php echo app('translator')->get('messages.nocat'); ?></h5>
            </div>
            <?php endif; ?>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<div class="container-fluid mt-auto">
    <hr>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($tags->links()); ?>

        </div>
    </div>
    <footer class="blog-footer">
    <?php if(count($pages) > 0): ?>
        <ul class="list-inline">
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <li class="list-inline-item">
                <a class="text-mode" href="<?php echo e(url('/page/' . $page->page_slug)); ?>"><?php echo e($page->page_title); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <?php if(!empty($setting->footer)): ?>
    <div class="text-muted"><?php echo clean($setting->footer); ?></div>
    <?php endif; ?>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/tags.blade.php ENDPATH**/ ?>