
<?php $__env->startSection('bodyclass'); ?>
    <body class="d-flex flex-column h-100">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">     
            <div class="card">
                <div class="card-body">
                    <h1><?php echo e($page->page_title); ?></h1>
                    <?php echo $page->page_content; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<div class="container-fluid mt-auto">
<hr>
<footer class="blog-footer">
<?php if(count($pages) > 0): ?>
    <ul class="list-inline">
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
        <li class="list-inline-item">
            <a class="text-mode" href="<?php echo e(url('/page/' . $page->page_slug)); ?>"><?php echo e($page->page_title); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php if(!empty($setting->footer)): ?>
<div class="text-muted"><?php echo clean($setting->footer); ?></div>
<?php endif; ?>
</footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/showpage.blade.php ENDPATH**/ ?>