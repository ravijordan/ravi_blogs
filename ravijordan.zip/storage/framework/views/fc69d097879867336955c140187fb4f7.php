<?php $__env->startSection('bodyclass'); ?>
    <body>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
<div class="jumbotron bg-none">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <h1 class="display-4"><?php echo app('translator')->get('messages.sign.title'); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container pt-5 pb-4">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 form-label"><?php echo app('translator')->get('messages.sign.name'); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                        <?php if($errors->has('name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                    <label for="name" class="col-md-4 form-label"><?php echo app('translator')->get('messages.sign.username'); ?></label>

                    <div class="col-md-6">
                        <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                        <?php if($errors->has('username')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email" class="col-md-4 form-label"><?php echo app('translator')->get('messages.sign.email'); ?></label>

                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                        <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="col-md-4 form-label"><?php echo app('translator')->get('messages.sign.password'); ?></label>

                    <div class="col-md-6">
                        <input id="password" type="password" class="form-control" name="password" required>

                        <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="password-confirm" class="col-md-4 form-label"><?php echo app('translator')->get('messages.sign.cpassword'); ?></label>

                    <div class="col-md-6">
                        <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary btnpoint">
                            <?php echo app('translator')->get('messages.sign.register'); ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/auth/register.blade.php ENDPATH**/ ?>