
<script src="<?php echo e(asset('/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/salvattore.min.js')); ?>"></script>
<script>
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl, {
	    animation: false // <-
	  })
	})
  var DataLink = "<?php echo e(url('/post')); ?>";
</script>
<script src="<?php echo e(asset('/js/heart.js')); ?>"></script><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/layouts/footer.blade.php ENDPATH**/ ?>