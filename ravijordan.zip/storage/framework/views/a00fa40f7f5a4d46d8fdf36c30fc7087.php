<?php 
print '<?xms- version="1.0" encoding="UTF-8" ?>'; 
?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:media="http://search.yahoo.com/mrss/">
<channel>
<title><?php echo e($setting->site_name . ' - ' . $setting->site_title); ?></title>
<description>RSS Feed</description>
<link><?php echo e(url('/')); ?></link>
<atom:link href="<?php echo e(url('/feed')); ?>" rel="self" type="application/atom+xms-" />
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $title = str_replace("&", "&amp;", $post->post_title);
    $title = stripslashes($post->post_title);
    if (!empty($post->post_desc)) {
      $description = str_replace("&rdquo;", "”", $post->post_desc);
      $description = str_replace("&ldquo;", "“", $post->post_desc);
      $pdescription = stripslashes($post->post_desc);
    } else {
      $description = null;
    }
    ?>

    <item>
        <title><?php echo e($title); ?></title>
        <description><?php echo e($description); ?></description>
        <pubDate><?php echo e(date('D, d M Y H:i:s', strtotime($post->created_at))); ?> GMT</pubDate>
        <link><?php echo e(url('/posts/' . $post->post_slug )); ?></link>
        <guid><?php echo e(url('/posts/' . $post->post_slug )); ?></guid>
    </item>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</channel>
</rss><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/feed.blade.php ENDPATH**/ ?>