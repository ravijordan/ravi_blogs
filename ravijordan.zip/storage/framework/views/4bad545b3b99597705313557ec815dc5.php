
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo app('translator')->get('admin.editadminprofile'); ?></h1>        
        <div class="btn-toolbar mb-2 mb-md-0">
            <span class="badge bg-light text-dark"><?php echo app('translator')->get($admin->role); ?></span>
        </div>    
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-secret')): ?>
    <div class="box-white ms-3 me-3 shadow-sm">   
        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form method="POST" action="<?php echo e(url('/adminprofile/' . $admin->id)); ?>" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>
            <div class="mb-3 row">
                <label for="name" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.name'); ?></label>
                <div class="col-sm-7">
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($admin->name); ?>" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="username" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.username'); ?></label>
                <div class="col-sm-7">
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo e($admin->username); ?>" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="email"  class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.email'); ?></label>
                <div class="col-sm-7">
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($admin->email); ?>" required>
                </div>
            </div>
            <div class="mb-3 row">
            <label class="col-sm-4 col-form-label" ><?php echo app('translator')->get('messages.new.cover_image'); ?></label>
                <div class="col-sm-7">     
                    <input type="file" class="form-control-file" id="cover" name="cover" aria-describedby="fileHelp">
                    <small id="fileHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.new.coverimg_help'); ?></small>
                </div>
            </div>
            <div class="mb-3 row">
                <label class="col-sm-4 col-form-label" ><?php echo app('translator')->get('admin.image'); ?></label>
                <div class="col-sm-7">     
                    <input type="file" class="form-control-file" id="avatar" name="avatar" aria-describedby="fileHelp">
                    <small id="fileHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.new.img_sizehelp'); ?></small>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="website" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.website'); ?></label>
                <div class="col-sm-7">
                    <input type="text" class="form-control" id="website" name="website" value="<?php echo e($admin->website); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="facebook" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.facebook'); ?></label>
                <div class="col-sm-7">
                        <input type="text" class="form-control" id="facebook" name="facebook" value="<?php echo e($admin->facebook); ?>" placeholder="<?php echo app('translator')->get('admin.username'); ?>">      
                </div>
            </div>
            <div class="mb-3 row">
                <label for="twitter" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.twitter'); ?></label>
                <div class="col-sm-7">
                        <input type="text" class="form-control" id="twitter" name="twitter" value="<?php echo e($admin->twitter); ?>" placeholder="<?php echo app('translator')->get('admin.username'); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="instagram" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.instagram'); ?></label>
                <div class="col-sm-7">
                        <input type="text" class="form-control" id="instagram" name="instagram" value="<?php echo e($admin->instagram); ?>" placeholder="<?php echo app('translator')->get('admin.username'); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="linkedin" class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.linkedin'); ?></label>
                <div class="col-sm-7">
                    <input type="text" class="form-control" id="linkedin" name="linkedin" value="<?php echo e($admin->linkedin); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <div class="offset-sm-4 col-sm-7">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a href="<?php echo e(url('/home/')); ?>" class="btn btn-danger" role="button">Cancel</a> 
                </div>
            </div>
        </form>
    </div>
    <div class="box-white ms-3 me-3 shadow-sm">
        <form method="POST" action="<?php echo e(url('/adminprofile/' . $admin->id)); ?>" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>
            <div class="mb-3 row">
                <label for="password"  class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.password'); ?></label>
                <div class="col-sm-7">
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="password_confirmation"  class="col-sm-4 col-form-label"><?php echo app('translator')->get('admin.passwordconf'); ?></label>
                <div class="col-sm-7">
                    <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="offset-sm-4 col-sm-7">
                    <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('admin.changepass'); ?></button>
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/posts/adminprofile.blade.php ENDPATH**/ ?>