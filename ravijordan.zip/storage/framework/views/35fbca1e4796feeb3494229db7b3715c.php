<!DOCTYPE html>
<html lang="en" class="<?php echo e($theme); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?php echo e(!empty($post->post_desc) ? $post->post_desc : $setting->site_desc); ?>">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">
        <link rel="amphtml" href="<?php echo e(url('posts/' . $post->post_slug)); ?>/amp">
        <title><?php echo e(!empty($post->post_title) ? $setting->site_name . ' - ' .$post->post_title : $setting->site_name . ' - ' . $setting->site_title); ?></title>
        <!-- Facebook og-->
        <meta property="fb:app_id" content="<?php echo env('FACEBOOK_API_ID'); ?>" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:type" content="article" />
        <meta property="og:title" content="<?php echo e(!empty($post->post_title) ? $post->post_title : $setting->site_name . '-' . $setting->site_title); ?>" />
        <meta property="og:description" content="<?php echo e(!empty($post->post_desc) ? $post->post_desc : $setting->site_desc); ?>" />
        <?php if(!empty($post->post_media)): ?>
        <meta property="og:image" content="<?php echo e(url('/uploads/' . $post->post_media)); ?>" />
        <?php elseif(!empty($post->post_video)): ?>
        <meta property="og:image" content="https://i.ytimg.com/vi/<?php echo e($post->post_video); ?>/hqdefault.jpg"/>
        <?php else: ?>
        <meta property="og:image" content="<?php echo e(url('/images/social.png')); ?>" />
        <?php endif; ?>        
        <!-- Twitter card-->
        <meta name="twitter:card" content="summary_large_image" />
        <meta property="og:url" content="<?php echo e(Request::url()); ?>" />
        <meta property="og:title" content="<?php echo e(!empty($post->post_title) ? $post->post_title : $setting->site_name . '-' . $setting->site_title); ?>" />
        <meta property="og:description" content="<?php echo e(!empty($post->post_desc) ? $post->post_desc : $setting->site_desc); ?>" />
        <?php if(!empty($post->post_media)): ?>
        <meta name="og:image" content="<?php echo e(url('/uploads/' . $post->post_media)); ?>" />
        <?php elseif(!empty($post->post_video)): ?>
        <meta name="og:image" content="https://i.ytimg.com/vi/<?php echo e($post->post_video); ?>/hqdefault.jpg"/>
        <?php else: ?>
        <meta name="og:image" content="<?php echo e(url('/images/social.png')); ?>" />
        <?php endif; ?>

        <!-- Css styles-->
        <link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/instant.css')); ?>" rel="stylesheet">  
        <link href="<?php echo e(asset('/instanticon/style.css')); ?>" rel="stylesheet">
        <?php if(!empty($setting->site_analytic)): ?>
            <?php echo $setting->site_analytic; ?>

        <?php endif; ?>
    </head>
    <body>
        <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <div id="fb-root"></div>

        <?php echo $__env->yieldContent('extra'); ?>

        <?php if($setting->cookie_option == '0'): ?>
            <?php echo $__env->make('layouts.cookie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>            
            var processing = "<?php echo app('translator')->get('messages.form.processing'); ?>";
            var successCom = "<?php echo app('translator')->get('messages.comments.success'); ?>";
            var now = "<?php echo app('translator')->get('messages.comments.new'); ?>";
            var MsgEdit = "<?php echo app('translator')->get('messages.edit'); ?>";
            var MsgCancel = "<?php echo app('translator')->get('messages.cancel'); ?>";
            var MsgDelete = "<?php echo app('translator')->get('messages.delete'); ?>";
            var MsgReply = "<?php echo app('translator')->get('messages.comments.reply'); ?>";
            var MsgSure = "<?php echo app('translator')->get('messages.comments.sure'); ?>";
            var siteURL = "<?php echo e(url('/')); ?>";
            var postID = "<?php echo e($post->id); ?>";
        </script>
        <script src="<?php echo e(asset('/js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/comment.js')); ?>"></script>
        <script async src="https://platform.twitter.com/widgets.js"></script>
        <script async defer src="//platform.instagram.com/en_US/embeds.js"></script>
        <script async defer src="//assets.pinterest.com/js/pinit.js"></script>
        <script>
            window.fbAsyncInit = function() {
                FB.init({
                  appId            : '<?php echo e(env("FACEBOOK_API_ID")); ?>',
                  autoLogAppEvents : true,
                  xfbml            : true,
                  version          : 'v12.0'
                });
            };

            (function(d, s, id){
                   var js, fjs = d.getElementsByTagName(s)[0];
                   if (d.getElementById(id)) {return;}
                   js = d.createElement(s); js.id = id;
                   js.src = "https://connect.facebook.net/en_US/sdk.js";
                   fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
    </body>
</html><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/layouts/mastershow.blade.php ENDPATH**/ ?>