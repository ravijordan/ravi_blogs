<?php $__env->startSection('bodyclass'); ?>
    <body class="bg-userside">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
    <div class="jumbotron">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <h1 class="display-4"><?php echo app('translator')->get('messages.home.title'); ?></h1>
                    <?php if(isset(auth()->user()->role)): ?>
                    <h6><?php echo app('translator')->get('messages.home.youare'); ?> <?php echo app('translator')->get(auth()->user()->role); ?></h6>
                    <?php endif; ?>
                </div>
                <div class="col-md-3">
                    <div class="admin-item-img">
                        <a href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>">
                            <?php if(substr( auth()->user()->avatar, 0, 4 ) === "http"): ?>
                            <img src="<?php echo e(auth()->user()->avatar); ?>" class="admin-image rounded-circle">
                            <?php else: ?>
                            <img src="<?php echo e(url('/images/' . auth()->user()->avatar)); ?>" class="admin-image rounded-circle">
                            <?php endif; ?>
                        </a>
                    </div>
                    <a href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>">
                        <p class="member-item-user"><?php echo e(auth()->user()->name); ?></p>
                    </a>
                    <p class="member-item-text"><?php echo e(auth()->user()->username); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <div class="container pt-5 pb-5">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-area')): ?>
        <div class="row ms-3 me-3">
            <div class="col-12">
                <section class="admin admin-simple-sm p-3 card-shadow">
                    <h6> <?php echo app('translator')->get('messages.home.logged'); ?> <a href="<?php echo e(url('/admin')); ?>"><?php echo app('translator')->get('messages.home.admin'); ?></a></h6>
                </section>
            </div>
        </div>
        <?php endif; ?>
        <div class="row ms-3 me-3">
            <div class="col-12">
                <section class="admin admin-simple-sm p-3 card-shadow">                
                <form method="POST" action="<?php echo e(url('/homepreference/' . auth()->user()->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <span class="h6"> <?php echo app('translator')->get('messages.new.homepreference'); ?> : </span>
                    <div class="form-check form-check-inline ms-4">
                        <label class="form-check-label" for="homepage1">
                        <input class="form-check-input" 
                            <?php if(auth()->user()->homepage == '0'): ?>
                            checked="checked" 
                            <?php endif; ?>
                            type="radio" name="homepage" id="homepage1" value="0"> <span class="h6"> <?php echo app('translator')->get('messages.new.viewallposts'); ?> </span>
                        </label>
                    </div>
                    <div class="form-check form-check-inline">
                        <label class="form-check-label" for="homepage2">
                        <input class="form-check-input" 
                            <?php if(auth()->user()->homepage == '1'): ?>
                            checked="checked" 
                            <?php endif; ?>
                            type="radio" name="homepage" id="homepage2" value="1">
                        <span class="h6"><?php echo app('translator')->get('messages.new.viewfollowingposts'); ?> </span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary"><?php echo app('translator')->get('messages.save'); ?></button>
                </form>
                </section>
            </div>
        </div>
        <div class="row m-3">
            <?php if (\Illuminate\Support\Facades\Blade::check('modorall')): ?>
            <div class="col-md-3">
                <a  href="<?php echo e(url('/home/add')); ?>" role="button" class="btn btn-lg w-100 btnhome me-1 mb-2"> <i class="icon-plus-circle"></i> <br> <?php echo app('translator')->get('messages.home.addpost'); ?></a>
            </div>
            <?php endif; ?>
            <div class="col-md-3">
                <a href="<?php echo e(url('/notifications')); ?>" role="button" class="btn btn-lg w-100 btnhome me-1 mb-2"><i class="icon-bell"></i> <br><?php echo app('translator')->get('messages.comments.notifications'); ?>
                    <?php if(count(auth()->user()->unreadNotifications) > 0): ?>
                    <span class="badge bg-danger"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="col-md-3">
                <a href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>" role="button" class="btn btn-lg w-100 btnhome me-1 mb-2"><i class="icon-person"></i> <br><?php echo app('translator')->get('messages.home.profile'); ?></a>
            </div>
            <div class="col-md-3">
                <a href="<?php echo e(url('/')); ?>" role="button" class="btn btn-lg w-100 btnhome me-1 mb-2"><i class="icon-house-door"></i> <br><?php echo app('translator')->get('messages.home.homepage'); ?></a>
            </div>
        </div>
        <?php if(!empty($posts->items())): ?>
        <div class="row ms-3 me-3">
            <div class="col-12">
                <section class="admin admin-simple-sm p-3 card-shadow">
                    <h6 class="text-secondary mb-4"> <?php echo app('translator')->get('messages.home.unpublished'); ?> </h6>
                    <table class="table table-sm table-striped">
                      <form action="<?php echo e(url('/cnt/multiple/')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('POST')); ?>

                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a class="text-mode" href="<?php echo e(url('/posts/' . $post->post_slug)); ?>" target="_blank">
                                        <?php if(! empty($post->post_title)): ?>
                                        <?php echo e(str_limit($post->post_title, 35)); ?>

                                        <?php else: ?>
                                        <?php echo app('translator')->get('messages.home.notitle'); ?>
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moderator-post')): ?>
                                    <a class="text-mode" href="<?php echo e(url('/profile/' . $post->user->username)); ?>" target="_blank"><?php echo e(str_limit($post->user->name, 10)); ?></a>    
                                    <?php else: ?>
                                    <small class="font-italic text-muted"><?php echo app('translator')->get('messages.home.awaiting'); ?></small>
                                    <?php endif; ?>
                                </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moderator-post')): ?>
                                <td><a class="text-success" href="<?php echo e(url('/publishpost/' . $post->id)); ?>"><?php echo app('translator')->get('messages.form.publish'); ?></a></td>
                                <?php endif; ?>
                                <td><a href="<?php echo e(url('/home/' . $post->id . '/edit')); ?>"><?php echo app('translator')->get('messages.edit'); ?></a></td>
                                <td><a class="color-delete" href="<?php echo e(url('/home/' . $post->id)); ?>"><?php echo app('translator')->get('messages.delete'); ?></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h5>
                                <?php echo app('translator')->get('messages.nopost'); ?>
                            </h5>
                            <?php endif; ?>
                        </tbody>
                    </form>
                </table>
            </section>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
    <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/form.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/home.blade.php ENDPATH**/ ?>