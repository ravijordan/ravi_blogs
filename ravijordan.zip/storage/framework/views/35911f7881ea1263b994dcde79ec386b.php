
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2"><?php echo app('translator')->get('admin.users'); ?></h1>    
    </div>
    <div class="row box-white ms-3 me-3 shadow-sm">
        <table class="table table-sm table-hover">
            <thead>
                <tr>
                    <th><?php echo app('translator')->get('admin.id'); ?></th>
                    <th><?php echo app('translator')->get('admin.name'); ?></th>
                    <th><?php echo app('translator')->get('admin.username'); ?></th>
                    <th><?php echo app('translator')->get('admin.role'); ?></th>
                    <th><?php echo app('translator')->get('admin.edit'); ?></th>
                    <th><?php echo app('translator')->get('admin.delete'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>      
                <tr> 
                    <th scope="row"><?php echo e($user->id); ?></th>
                    <td>
                        <a href="<?php echo e(url('/profile/' . $user->username)); ?>">
                            <?php echo e($user->name); ?>

                        </a>
                    </td>
                    <td><?php echo e($user->username); ?></td>
                    <td>
                    <?php if($user->status == "1"): ?>
                    <label class="badge bg-danger"><?php echo app('translator')->get('admin.banned'); ?></label>
                    <?php elseif(isset($user->role)): ?>
                    <label class="badge bg-info"><?php echo e($user->role); ?></label>
                    <?php endif; ?>
                    </td>
                    <td><a href="<?php echo e(url('/users/' . $user->username . '/edit')); ?>">Edit</a></td>
                    <td><a class="color-delete" href="<?php echo e(url('/users/' . $user->username)); ?>"><?php echo app('translator')->get('admin.delete'); ?></a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php echo app('translator')->get('admin.nouser'); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/posts/users.blade.php ENDPATH**/ ?>