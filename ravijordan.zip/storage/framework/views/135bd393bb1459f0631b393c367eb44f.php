<div class="mb-3 row">
    <label for="post_select" class="offset-md-1 col-sm-2 col-form-label">
        <?php echo app('translator')->get('messages.form.category'); ?>
    </label>
    <div class="col-sm-7">
        <select id="post_select" class="form-select" name="tag_id">
            <option value=""><?php echo app('translator')->get('messages.form.select_category'); ?></option>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($tag->id); ?>" 
                <?php if(isset($postTag)): ?>
                <?php echo e($postTag->pivot->tag_id == $tag->id ? 'selected="selected"' : ''); ?>

                <?php endif; ?>
                ><?php echo e($tag->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/posts/tagselect.blade.php ENDPATH**/ ?>