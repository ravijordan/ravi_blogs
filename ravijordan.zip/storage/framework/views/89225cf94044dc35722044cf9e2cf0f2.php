
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/quill/dist/quill.snow.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('/js/Sortable.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bodyclass'); ?>
<body class="bg-userside">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
    <div class="jumbotron">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-9">
                    <h1 class="display-4"><?php echo app('translator')->get('messages.form.title_add'); ?></h1>
                </div>
                <div class="col-md-3">
                    <?php if(auth()->guard()->check()): ?>
                    <div class="admin-item-img">
                        <a href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>">
                            <?php if(substr( auth()->user()->avatar, 0, 4 ) === "http"): ?>
                            <img src="<?php echo e(auth()->user()->avatar); ?>" class="admin-image rounded-circle">
                            <?php else: ?>
                            <img src="<?php echo e(url('/images/' . auth()->user()->avatar)); ?>" class="admin-image rounded-circle">
                            <?php endif; ?>
                        </a>
                    </div>                    
                    <a href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>">
                        <p class="member-item-user"><?php echo e(auth()->user()->name); ?></p>
                    </a>
                    <p class="member-item-text"><?php echo e(auth()->user()->username); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('modorall')): ?>
    <div class="container">
        <div class="content pt-5 pb-4">
            <div id="show-msg" class="alert alert-success print-success-msg d-none" role="alert">
            </div>
            <form method="POST" action="<?php echo e(url('/home')); ?>" id="post_form">
                <div class="mb-3 row">
                    <label for="post_title" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.title'); ?></label>
                    <div class="col-md-7">
                        <input type="text" class="form-control" id="post_title" name="post_title">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="post_desc" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.description'); ?></label>
                    <div class="col-md-7">
                        <textarea class="form-control" id="post_desc" name="post_desc"></textarea>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="post_desc" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.type'); ?></label>
                    <div class="col-md-7">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="pills-image-tab" data-bs-toggle="pill" href="#pills-image" role="tab" aria-controls="pills-image" aria-selected="true"><?php echo app('translator')->get('messages.form.imagepost'); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-video-tab" data-bs-toggle="pill" href="#pills-video" role="tab" aria-controls="pills-video" aria-selected="false"><?php echo app('translator')->get('messages.form.videopost'); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="pills-text-tab" data-bs-toggle="pill" href="#pills-text" role="tab" aria-controls="pills-text" aria-selected="false"><?php echo app('translator')->get('messages.form.textpost'); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-image" role="tabpanel" aria-labelledby="pills-image-tab">
                        <div class="mb-3 row">
                            <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.upload'); ?></label>
                            <div class="col-md-7 d-flex">
                            <div class="fileinputs me-3">
                                <label class="btn btn-info btnfile"><?php echo app('translator')->get('messages.form.browse'); ?>
                                    <input onchange="ImageUpload(this)" class="fileupload d-none" type="file" name="post_image">
                                </label>
                            </div>
                            <input class="photo_upload" name="post_media" type="hidden" value="">
                            <div class="fileinfo d-flex">
                            </div>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.imgoverlay'); ?></label>
                            <div class="col-sm-7">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="gridCheck1" name="post_instant" value="1">
                                    <label class="form-check-label" for="gridCheck1">
                                    <?php echo app('translator')->get('messages.form.imgoverlay_check'); ?>
                                </label>
                                </div>
                           </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
                        <div class="mb-3 row">
                            <label for="post_video" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.postvideo'); ?></label>
                            <div class="col-md-7">
                                <input type="text" class="form-control" id="post_video" name="post_video" aria-describedby="videoHelp">
                                <small id="videoHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.form.videoex'); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-text" role="tabpanel" aria-labelledby="pills-text-tab">
                        <div class="mb-3 row">
                            <label for="post_video" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.bg'); ?></label>
                            <div class="col-md-7">
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio1" value="bg-primary" checked>
                                        <label class="form-check-label color-box bg-primary text-white" for="inlineRadio1"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio2" value="bg-secondary">
                                        <label class="form-check-label color-box bg-secondary text-white" for="inlineRadio2"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio3" value="bg-danger">
                                        <label class="form-check-label color-box bg-danger text-white" for="inlineRadio3"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio4" value="bg-warning">
                                        <label class="form-check-label color-box bg-warning text-white" for="inlineRadio4"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio5" value="bg-info">
                                        <label class="form-check-label color-box bg-info text-white" for="inlineRadio5"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                                <div class="form-check form-check-inline">    
                                    <input class="form-check-input" type="radio" name="post_color" id="inlineRadio6" value="bg-dark">
                                        <label class="form-check-label color-box bg-dark text-white" for="inlineRadio6"><i class="icon-card-list"></i>
                                    </label> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo $__env->make('posts.tagselect', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="dynamic_field">
                </div>

                <div class="mb-3 row mb-5">
                    <label class="offset-md-1 col-md-2 col-form-label"><strong><?php echo app('translator')->get('messages.form.more'); ?> </strong> <a href="#" data-bs-toggle="modal" data-bs-target="#helpModal"><i class="icon-info-circle"></i></a>
                    </label>
                    <div class="col-md-7">             
                        <button onclick="addNew('header_add')" type="button" name="header_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addheading'); ?>"><i class="icon-type-h1"></i></button>
                        <button onclick="addNew('txt_add')" type="button" name="txt_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addsimple'); ?>"><i class="icon-fonts"></i></button>
                        <button onclick="addText()" type="button" id="texteditor" class="btn btn-lg btn-light me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addeditor'); ?>"><i class="icon-textarea-t"></i></button>
                        <button onclick="addNew('img_add')" type="button" name="img_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addimage'); ?>"><i class="icon-image"></i></button>
                        <button onclick="addNew('youtube_add')" type="button" name="youtube_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addyoutube'); ?>"><i class="icon-youtube"></i></button>
                        <button onclick="addNew('tweet_add')" type="button" name="tweet_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addtweet'); ?>"><i class="icon-twitter"></i></button>
                        <button onclick="addNew('face_add')" type="button" name="face_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addfb'); ?>"><i class="icon-facebook"></i></button>
                        <button onclick="addNew('instagram_add')" type="button" name="instagram_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addinst'); ?>"><i class="icon-instagram"></i></button>
                        <button onclick="addNew('pinterest_add')" type="button" name="pinterest_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addpin'); ?>"><i class="icon-pinterest"></i></button>
                        <button onclick="addNew('tiktok_add')" type="button" name="tiktok_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addtiktok'); ?>"><i class="icon-tiktok"></i></button>
                    </div>
                </div>
                <div id="subbtn" class="mb-3 row mb-5">
                    <div class="offset-md-3 col-md-7">
                        <div id="show-err-msg" class="text-danger print-error-msg d-none">
                            <ul id="list"></ul>
                        </div>   
                        <button onclick="ClickForm()" id="submit" class="btn btn-success"><?php echo app('translator')->get('messages.form.submit'); ?></button>
                    </div>
                </div>
            </form>
            <div class="modal fade" id="helpModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('messages.form.addex'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th scope="row">Heading</th>
                                        <td class="font-italic">This is my Heading.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Text</th>
                                        <td class="font-italic">This is my text.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Text Editor</th>
                                        <td class="font-italic">This is my <strong>text</strong> with style.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Image</th>
                                        <td class="font-italic">Upload Image here.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Youtube</th>
                                        <td class="font-italic">https://www.youtube.com/watch?v=_38JDGnr0vA</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Tweet</th>
                                        <td class="font-italic">https://twitter.com/Interior/status/463440424141459456</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Facebook</th>
                                        <td class="font-italic">https://www.facebook.com/20531316728/posts/10154009990506729/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Instagram</th>
                                        <td class="font-italic">https://www.instagram.com/p/tsxp1hhQTG/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Pinterest</th>
                                        <td class="font-italic">https://www.pinterest.com/pin/99360735500167749/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Tiktok</th>
                                        <td class="font-italic">https://www.tiktok.com/@scout2015/video/6718335390845095173</td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('posts.formfields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
        </div>
    </div>
    <?php else: ?>
    <div class="container">
        <h5><?php echo app('translator')->get('messages.form.nofound'); ?></h5>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/quill/dist/quill.min.js')); ?>"></script>
<script>
    var embedURL = "<?php echo e(url('admincp/postEmbed')); ?>";
    var imgURL = "<?php echo e(url('admincp/uploadImg')); ?>";
    var delURL = "<?php echo e(url('admincp/deleteImg')); ?>";
    var avatarURL = "<?php echo e(url('/uploads/')); ?>";
    var delContent = "<?php echo e(url('/delete/content')); ?>";
    var embedtxt = "<?php echo app('translator')->get('messages.form.embed'); ?>";
    var editortxt = "<?php echo app('translator')->get('messages.form.editor'); ?>";
    var removetxt = "<?php echo app('translator')->get('messages.form.removetxt'); ?>";
    var processing = "<?php echo app('translator')->get('messages.form.processing'); ?>";
    var submittxt = "<?php echo app('translator')->get('messages.form.submittxt'); ?>";
    var browse = "<?php echo app('translator')->get('messages.form.browse'); ?>";
    var formtext = "<?php echo app('translator')->get('messages.form.text'); ?>";        
    var imguploaded = "<?php echo app('translator')->get('messages.form.imguploaded'); ?>";
    var imgremoved = "<?php echo app('translator')->get('messages.form.imgremoved'); ?>";
    var fileUploading = "<?php echo app('translator')->get('messages.form.file_uploading'); ?>";
    var blank = "<?php echo app('translator')->get('messages.new.blank'); ?>";
    var imagealt = "<?php echo app('translator')->get('messages.new.imagealt'); ?>";
    var link = "<?php echo app('translator')->get('messages.new.link'); ?>";
    var self = "<?php echo app('translator')->get('messages.new.self'); ?>";
    Sortable.create(dynamic_field, {
          handle: '.span-move',
          animation: 150,
    });   
</script>
<script src="<?php echo e(asset('/js/form.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/member/add.blade.php ENDPATH**/ ?>