<nav class="navbar navbar-expand-lg sticky-top p-0 navbar-light bg-white shadow-sm">
  <div class="container-fluid p-0">
   <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3" href="<?php echo e(url('/admin')); ?>">Admin Panel</a>
   <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
          <a class="nav-link me-3 dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php if(substr( auth()->user()->avatar, 0, 4 ) === "http"): ?>
                <img class="avatar-xs img-fluid rounded-circle" src="<?php echo e(auth()->user()->avatar); ?>">
                <?php else: ?>
                <img class="avatar-xs img-fluid rounded-circle" src="<?php echo e(url('/images/' . auth()->user()->avatar)); ?>">
                <?php endif; ?>
                <?php echo e(auth()->user()->name); ?>

                </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="<?php echo e(url('/home')); ?>"><?php echo app('translator')->get('messages.mpanel'); ?></a>
              <a class="dropdown-item" href="<?php echo e(url('/profile/' . auth()->user()->username)); ?>"><?php echo app('translator')->get('messages.mpro'); ?></a>
              <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
              <?php echo app('translator')->get('messages.logout'); ?>
              </a>
              <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
              </form>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/layouts/adminnav.blade.php ENDPATH**/ ?>