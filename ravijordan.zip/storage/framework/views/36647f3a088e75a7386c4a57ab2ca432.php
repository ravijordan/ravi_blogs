
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('/quill/dist/quill.snow.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('/js/Sortable.js')); ?>"></script>
<script src="<?php echo e(asset('/quill/dist/quill.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bodyclass'); ?>
    <body class="bg-userside">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
<div class="jumbotron">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <h1 class="display-4"><?php echo app('translator')->get('messages.form.title_edit'); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="content pt-5 pb-4">
    <div id="show-msg" class="alert alert-success print-success-msg d-none" role="alert">
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['own-post', 'moderator-post'], $post)): ?>
        <form method="POST" action="<?php echo e(url('/home/' . $post->id)); ?>" id="post_form">
            <?php echo e(method_field('PUT')); ?>

            <div class="mb-3 row">
                <label for="post_title" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.title'); ?></label>
                <div class="col-md-7">
                    <input type="text" class="form-control" id="post_title" name="post_title" value="<?php echo e($post->post_title); ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="post_slug" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.slug'); ?></label>
                <div class="col-md-7">
                    <input type="text" class="form-control" id="post_slug" name="post_slug" value="<?php echo e($post->post_slug); ?>" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="post_desc" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.description'); ?></label>
                <div class="col-md-7">
                    <textarea class="form-control" id="post_desc" name="post_desc"><?php echo e($post->post_desc); ?></textarea>
                </div>
            </div>
            <div class="mb-3 row">
              <label for="post_desc" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.type'); ?></label>
              <div class="col-md-7">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link <?php echo e(!empty($post->post_media) & empty($post->post_video)  ? 'active' : ''); ?>" id="pills-image-tab" data-bs-toggle="pill" href="#pills-image" role="tab" aria-controls="pills-image" aria-selected="true"><?php echo app('translator')->get('messages.form.imagepost'); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link <?php echo e(!empty($post->post_video) ? 'active' : ''); ?>" id="pills-video-tab" data-bs-toggle="pill" href="#pills-video" role="tab" aria-controls="pills-video" aria-selected="false"><?php echo app('translator')->get('messages.form.videopost'); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link <?php echo e(empty($post->post_video OR $post->post_media) ? 'active' : ''); ?>" id="pills-text-tab" data-bs-toggle="pill" href="#pills-text" role="tab" aria-controls="pills-text" aria-selected="false"><?php echo app('translator')->get('messages.form.textpost'); ?></a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-image" role="tabpanel" aria-labelledby="pills-image-tab">
                <?php if(!empty($post->post_media)): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.upload'); ?></label>
                    <div class="col-md-7 d-flex">
                    <div class="fileinputs me-3">
                        <button onclick="ImageRemove(this)" type="button" class="btn btn-warning editimage"><?php echo app('translator')->get('messages.form.removetxt'); ?></button>
                    </div>
                    <input class="photo_upload" name="post_media" type="hidden" value="<?php echo e($post->post_media); ?>">
                    <div class="fileinfo d-flex">
                            <div class='flex-shrink-0'>
                                <img class='imgthumb img-fluid me-2' src="<?php echo e(url('/uploads/' . $post->post_media)); ?>">
                            </div>
                            <div class='flex-grow-1 ms-3'>
                                <input class='form-control' type='text' name='media_alt' placeholder='<?php echo app('translator')->get("messages.new.imagealt"); ?>' aria-label='Image Alt' value="<?php echo e($post->media_alt); ?>">
                            </div>
                    </div>
                    </div>
                </div>
                <div class="mb-3 row">
                        <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.imgoverlay'); ?></label>
                    <div class="col-sm-7">
                        <div class="form-check">
                            <?php if($post->post_instant == "1"): ?>
                            <input class="form-check-input" type="checkbox" id="gridCheck1" name="post_instant" value="1" checked>
                            <?php else: ?>
                            <input class="form-check-input" type="checkbox" id="gridCheck1" name="post_instant" value="0">
                            <?php endif; ?>
                            <label class="form-check-label" for="gridCheck1">
                                <?php echo app('translator')->get('messages.form.imgoverlay_check'); ?>
                            </label>
                        </div>
                    </div>
                 </div>
                <?php else: ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.upload'); ?></label>
                    <div class="col-md-7 d-flex">
                        <div class="fileinputs me-3">
                            <label class="btn btn-info btnfile"><?php echo app('translator')->get('messages.form.browse'); ?>
                                <input onchange="ImageUpload(this)" class="fileupload d-none" type="file" name="post_image">
                            </label>
                        </div>
                        <input class="photo_upload" name="post_media" type="hidden" value="">
                        <div class="fileinfo d-flex">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
              </div>
              <div class="tab-pane fade" id="pills-video" role="tabpanel" aria-labelledby="pills-video-tab">
                <div class="mb-3 row">
                    <label for="post_video" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.postvideo'); ?></label>
                    <div class="col-md-7">
                        <input type="text" class="form-control" id="post_video" name="post_video" aria-describedby="videoHelp" value="<?php echo e($post->video_url); ?>">
                        <small id="videoHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.form.videoex'); ?></small>
                    </div>
                </div>
              </div>
              <div class="tab-pane fade" id="pills-text" role="tabpanel" aria-labelledby="pills-text-tab">
                <div class="mb-3 row">
                  <label for="post_video" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.bg'); ?></label>
                 <div class="col-md-7">
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio1" value="bg-primary" checked>
                            <label class="form-check-label color-box bg-primary text-white" for="inlineRadio1"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio2" value="bg-secondary">
                            <label class="form-check-label color-box bg-secondary text-white" for="inlineRadio2"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio3" value="bg-danger">
                            <label class="form-check-label color-box bg-danger text-white" for="inlineRadio3"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio4" value="bg-warning">
                            <label class="form-check-label color-box bg-warning text-white" for="inlineRadio4"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio5" value="bg-info">
                            <label class="form-check-label color-box bg-info text-white" for="inlineRadio5"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    <div class="form-check form-check-inline">    
                        <input class="form-check-input" type="radio" name="post_color" id="inlineRadio6" value="bg-dark">
                            <label class="form-check-label color-box bg-dark text-white" for="inlineRadio6"><i class="icon-card-list"></i>
                        </label> 
                    </div>
                    </div>
                </div>
              </div>
            </div>

            <?php echo $__env->make('posts.tagselect', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(auth()->user()->can('moderator-post') OR $post->post_live == 1): ?>
            <div class="mb-3 row">
                <label for="post_live" class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.publish'); ?></label>
                <div class="col-md-7">
                    <input type="checkbox" class="form-check-input" name="post_live" <?php echo e($post->post_live == 1 ? 'checked' : ''); ?>>
                </div>
            </div>
            <?php endif; ?>

            <div id="dynamic_field">
                <?php
                    $divcount = 1;
                ?>
                <?php $__currentLoopData = $post->contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($content->type == "image"): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.upload'); ?></label>
                    <div class="col-md-7 d-flex">
                    <div class="fileinputs me-3">
                        <button onclick="ImageRemove(this)" type="button" class="btn btn-warning editimage"><?php echo app('translator')->get('messages.form.removetxt'); ?></button>
                    </div>
                    <input class="photo_upload" name="content[]" type="hidden" value="<?php echo e($content->body); ?>">
                    <input type="hidden" name="type[]" value="image">

                    <div class="fileinfo d-flex">
                        <div class='flex-shrink-0'>
                            <img class='imgthumb img-fluid me-2' src="<?php echo e(url('/uploads/' . $content->body)); ?>">
                        </div>
                        <div class='flex-grow-1 ms-3'>
                            <div class="input-group">
                                <input class="form-control" type="text" name="extra[]" placeholder="<?php echo app('translator')->get('messages.new.imagealt'); ?>" aria-label="Image Alt" value="<?php echo e($content->extra); ?>">
                                <input class="form-control" type="text" name="link[]" placeholder="<?php echo app('translator')->get('messages.new.link'); ?>" aria-label="Link" value="<?php echo e($content->link); ?>">
                                <select class='form-select short-select'  name='blank[]' aria-label='blankselect'>
                                    <option value='0'<?php echo e($content->blank == '0' ? 'selected' : ''); ?> ><?php echo app('translator')->get('messages.new.self'); ?></option>
                                    <option value='1' <?php echo e($content->blank == '1' ? 'selected' : ''); ?>><?php echo app('translator')->get('messages.new.blank'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-1 col-md-1 d-flex align-items-center">
                        <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                        <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                    </div>
                </div>
                <?php elseif($content->type == "text"): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.text'); ?></label>
                    <div class="col-sm-10 col-md-7">
                        <textarea class="form-control" name="content[]"><?php echo e($content->body); ?></textarea>
                        <input type="hidden" name="type[]" value="text">
                        <input type="hidden" name="extra[]">                        
                    </div>
                    <div class="col-sm-1 col-md-1 d-flex align-items-center">
                        <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                        <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                    </div>
                </div>
                <?php elseif($content->type == "txteditor"): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label">
                    <?php echo app('translator')->get('messages.form.editor'); ?></label>
                    <div class="col-sm-10 col-md-7 alleditor myeditor">
                        <div id="qeditor<?php echo e($divcount++); ?>">
                            <?php echo clean( $content->body ); ?>

                        </div>
                        <input class="txtcont" type="hidden" name="content[]">
                        <input type="hidden" name="type[]" value="txteditor">
                        <input type="hidden" name="extra[]">
                    </div>
                    <div class="col-sm-1 col-md-1 d-flex align-items-center mt-3">
                        <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                        <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                    </div>
                </div>
                <?php elseif($content->type == "youtube"): ?>
                    <div class="mb-3 row">
                        <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.youtube'); ?></label>
                        <div class="col-sm-10 col-md-7">
                            <input type="text" class="form-control" name="content[]" value="https://www.youtube.com/watch?v=<?php echo e($content->body); ?>">
                            <input type="hidden" name="type[]" value="youtube">
                            <input type="hidden" name="extra[]">
                        </div>
                        <div class="col-sm-1 col-md-1 d-flex align-items-center">
                            <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                            <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                        </div>
                    </div>
                <?php elseif($content->type == "header"): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo app('translator')->get('messages.form.heading'); ?></label>
                    <div class="col-sm-10 col-md-7">
                        <div class="input-group">
                            <input type="text" class="form-control w-85" name="content[]" placeholder="<?php echo app('translator')->get('messages.form.heading_help'); ?>" value="<?php echo e($content->body); ?>">
                            <input type="hidden" name="type[]" value="header">
                            <select class="form-select w-15" name="extra[]" aria-label="select">
                                <option value="h1" <?php echo e($content->extra == 'h1' ? 'selected' : ''); ?>>H1</option>
                              <option value="h2" <?php echo e($content->extra == 'h2' ? 'selected' : ''); ?>>H2</option>
                              <option value="h3" <?php echo e($content->extra == 'h3' ? 'selected' : ''); ?>>H3</option>
                              <option value="h4" <?php echo e($content->extra == 'h4' ? 'selected' : ''); ?>>H4</option>
                              <option value="h5" <?php echo e($content->extra == 'h5' ? 'selected' : ''); ?>>H5</option>
                              <option value="h6" <?php echo e($content->extra == 'h6' ? 'selected' : ''); ?>>H6</option>                      
                          </select>
                      </div>
                  </div>
                  <div class="col-sm-1 col-md-1 d-flex align-items-center">
                    <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                    <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                </div>                
            </div>
                <?php elseif(!empty($content->embed_id)): ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo e(title_case($content->type)); ?></label>
                    <div class="col-sm-10 col-md-7">
                    <div class="input-group">
                        <input type="text" class="form-control" name="embed_url" value="<?php echo e($content->embed->url); ?>" readonly>
                        <input type="hidden" class="form-control" name="content[]" value="<?php echo e($content->body); ?>">
                        <input type="hidden" name="type[]" value="<?php echo e($content->type); ?>">
                        <input type="hidden" name="extra[]">
                        <button onclick="RemoveEmbed(this)" class="btn btn-outline-warning" type="button"><?php echo app('translator')->get('messages.form.removetxt'); ?></button>
                    </div>
                    </div>
                    <div class="col-sm-1 col-md-1 d-flex align-items-center">
                        <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                        <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                    </div>
                </div>
                <?php else: ?>
                <div class="mb-3 row">
                    <label class="offset-md-1 col-md-2 col-form-label"><?php echo e(title_case($content->type)); ?></label>
                    <div class="col-sm-10 col-md-7">
                        <input type="text" class="form-control" name="content[]" value="<?php echo e($content->body); ?>">
                        <input type="hidden" name="type[]" value="<?php echo e($content->type); ?>">
                        <input type="hidden" name="extra[]">
                    </div>
                    <div class="col-sm-1 col-md-1 d-flex align-items-center">
                        <span class="span-click me-3 text-danger" onclick="delCont(this)"><i class="icon-x-circle fw-bold"></i></span>
                        <span class="span-move"><i class="icon-arrows-move fw-bold"></i></span>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mb-3 row mb-5">
                    <label class="offset-md-1 col-md-2 col-form-label"><strong><?php echo app('translator')->get('messages.form.more'); ?> </strong> <a href="#" data-bs-toggle="modal" data-bs-target="#helpModal"><i class="icon-info-circle"></i></a>
                    </label>
                    <div class="col-md-7">             
                        <button onclick="addNew('header_add')" type="button" name="header_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addheading'); ?>"><i class="icon-type-h1"></i></button>
                        <button onclick="addNew('txt_add')" type="button" name="txt_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addsimple'); ?>"><i class="icon-fonts"></i></button>
                        <button onclick="addText()" type="button" id="texteditor" class="btn btn-lg btn-light me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addeditor'); ?>"><i class="icon-textarea-t"></i></button>
                        <button onclick="addNew('img_add')" type="button" name="img_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addimage'); ?>"><i class="icon-image"></i></button>
                        <button onclick="addNew('youtube_add')" type="button" name="youtube_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addyoutube'); ?>"><i class="icon-youtube"></i></button>
                        <button onclick="addNew('tweet_add')" type="button" name="tweet_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addtweet'); ?>"><i class="icon-twitter"></i></button>
                        <button onclick="addNew('face_add')" type="button" name="face_add" class="btn btn-lg btn-light btnadd me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addfb'); ?>"><i class="icon-facebook"></i></button>
                        <button onclick="addNew('instagram_add')" type="button" name="instagram_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addinst'); ?>"><i class="icon-instagram"></i></button>
                        <button onclick="addNew('pinterest_add')" type="button" name="pinterest_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addpin'); ?>"><i class="icon-pinterest"></i></button>
                        <button onclick="addNew('tiktok_add')" type="button" name="tiktok_add" class="btn btn-lg btn-light btnadd" data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?php echo app('translator')->get('messages.form.addtiktok'); ?>"><i class="icon-tiktok"></i></button>
                    </div>
            </div>
            <div id="subbtn" class="mb-3 row mb-5">
                <div class="offset-md-3 col-md-7">
                    <div id="show-err-msg" class="text-danger print-error-msg d-none">
                            <ul id="list"></ul>
                        </div>              
                    <button onclick="ClickForm()" id="submit" class="btn btn-success"><?php echo app('translator')->get('messages.form.submit'); ?></button>
                </div>
            </div>
        </form>
        <div class="modal fade" id="helpModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo app('translator')->get('messages.form.addex'); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table table-sm">
                                <tbody>
                                    <tr>
                                        <th scope="row">Heading</th>
                                        <td class="font-italic">This is my Heading.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Text</th>
                                        <td class="font-italic">This is my text.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Text Editor</th>
                                        <td class="font-italic">This is my <strong>text</strong> with style.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Image</th>
                                        <td class="font-italic">Upload Image here.</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Youtube</th>
                                        <td class="font-italic">https://www.youtube.com/watch?v=_38JDGnr0vA</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Tweet</th>
                                        <td class="font-italic">https://twitter.com/Interior/status/463440424141459456</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Facebook</th>
                                        <td class="font-italic">https://www.facebook.com/20531316728/posts/10154009990506729/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Instagram</th>
                                        <td class="font-italic">https://www.instagram.com/p/tsxp1hhQTG/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Pinterest</th>
                                        <td class="font-italic">https://www.pinterest.com/pin/99360735500167749/</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Tiktok</th>
                                        <td class="font-italic">https://www.tiktok.com/@scout2015/video/6718335390845095173</td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        <?php echo $__env->make('posts.formfields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
    <div class="alert alert-warning" role="alert">
      <strong><?php echo app('translator')->get('messages.form.nofound'); ?></strong> <?php echo app('translator')->get('messages.backto'); ?> <a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('messages.hometxt'); ?></a>.
    </div>
    <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    var embedURL = "<?php echo e(url('admincp/postEmbed')); ?>";
    var imgURL = "<?php echo e(url('admincp/uploadImg')); ?>";
    var delURL = "<?php echo e(url('admincp/deleteImg')); ?>";
    var avatarURL = "<?php echo e(url('/uploads/')); ?>";
    var delContent = "<?php echo e(url('/delete/content')); ?>";
    var embedtxt = "<?php echo app('translator')->get('messages.form.embed'); ?>";
    var editortxt = "<?php echo app('translator')->get('messages.form.editor'); ?>";
    var removetxt = "<?php echo app('translator')->get('messages.form.removetxt'); ?>";
    var processing = "<?php echo app('translator')->get('messages.form.processing'); ?>";
    var submittxt = "<?php echo app('translator')->get('messages.form.submittxt'); ?>";
    var browse = "<?php echo app('translator')->get('messages.form.browse'); ?>";
    var formtext = "<?php echo app('translator')->get('messages.form.text'); ?>";        
    var imguploaded = "<?php echo app('translator')->get('messages.form.imguploaded'); ?>";
    var imgremoved = "<?php echo app('translator')->get('messages.form.imgremoved'); ?>";
    var fileUploading = "<?php echo app('translator')->get('messages.form.file_uploading'); ?>";
    var blank = "<?php echo app('translator')->get('messages.new.blank'); ?>";
    var imagealt = "<?php echo app('translator')->get('messages.new.imagealt'); ?>";
    var link = "<?php echo app('translator')->get('messages.new.link'); ?>";
    var self = "<?php echo app('translator')->get('messages.new.self'); ?>"
    Sortable.create(dynamic_field, {
          handle: '.span-move',
          animation: 150
    });

        let editors = document.querySelectorAll(".alleditor");
        if (editors.length > 0) {
            var ec = 1;
            var toolbarOptions = [
              ['bold', 'italic', 'underline', 'strike'],
              ['blockquote', 'code-block', 'link'],
              [{ 'list': 'ordered'}, { 'list': 'bullet' }],
              [{ 'color': [] }, { 'background': [] }],
              ['clean']
            ];
            editors.forEach(function() {
                var quill = new Quill('#qeditor'+ ec++, {
                theme: 'snow',
                modules: {
                    toolbar: toolbarOptions
                },
                });
            });
        }

</script>
<script src="<?php echo e(asset('/js/form.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/member/edit.blade.php ENDPATH**/ ?>