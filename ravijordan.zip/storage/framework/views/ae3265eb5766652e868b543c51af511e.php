<?php $__env->startSection('bodyclass'); ?>
    <body>
<?php $__env->stopSection(); ?>
<?php if($setting->site_instant == 1): ?>
<?php $__env->startSection('jumbotron'); ?>
<div class="jumbotron bg-none">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <h1 class="display-4"><?php echo app('translator')->get('messages.login.title'); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container pt-5 pb-4">
    <div class="d-md-flex flex-row">
        <div class="col-md-4">
            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-3<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                    <label for="username" class="form-label"><?php echo app('translator')->get('messages.login.username'); ?></label>
                    <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>
                        <?php if($errors->has('username')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                        <?php endif; ?>
                </div>

                <div class="mb-3<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="form-label"><?php echo app('translator')->get('messages.login.password'); ?></label>
                    <input id="password" type="password" class="form-control" name="password" required>
                    <?php if($errors->has('password')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="mb-3">             
                <div class="checkbox">
                    <label class="form-label">
                    <?php echo app('translator')->get('messages.login.dont'); ?>
                    <a href="<?php echo e(route('register')); ?>"><strong> <?php echo app('translator')->get('messages.login.sign'); ?></strong></a>
                    </label>
                </div>
                <div class="checkbox">
                    <label class="form-label">
                    <?php echo app('translator')->get('messages.login.forgot'); ?>
                    <a href="<?php echo e(route('password.request')); ?>"><strong> <?php echo app('translator')->get('messages.login.click'); ?></strong></a>
                    </label>
                </div>
                </div>
                <div class="mb-3">                    
                    <button type="submit" class="btn btn-primary btnpoint">
                        <?php echo app('translator')->get('messages.login.button'); ?>
                    </button>
                </div>
            </form>
        </div>
        <div class="col-md-1 pt-md-5">
            <div class="ordiv mt-3">
                <strong>OR</strong>
            </div>
        </div>
        <div class="col-md-3 mt-5">
             <div class="sociallogin mb-3">
                <a role="button" class="btn btn-face-login social" href="<?php echo e(url('/auth/facebook')); ?>" ><img src="<?php echo e(url('/images/facebook_logo.png')); ?>" class="me-2"> <?php echo app('translator')->get('messages.login.facebook'); ?></a>
            </div>
             <div class="sociallogin">
                <a role="button" class="btn btn-google-login social" href="<?php echo e(url('/auth/google')); ?>" ><img src="<?php echo e(url('/images/google_logo.png')); ?>" width="37" class="me-3"> <?php echo app('translator')->get('messages.login.google'); ?></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php echo $__env->make('member.information', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/auth/login.blade.php ENDPATH**/ ?>