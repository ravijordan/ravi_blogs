
<?php $__env->startSection('bodyclass'); ?>
    <body class="d-flex flex-column h-100">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div id="se-pre-con" class="d-flex justify-content-center align-items-center">
    <div class="spinner-grow me-1 text-danger" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
    <div class="spinner-grow me-1 text-warning" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
    <div class="spinner-grow me-1 text-info" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
</div>
<div id="maincontent" class="container-fluid mt-5 d-none">
    <div class="row">
        <div class="grid" data-columns>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('public.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(!empty($setting->between_ads)): ?>
                    <?php if( ($key + 1) % 9 == 0 ): ?>
                    <div class="card betads embed-responsive">
                        <?php echo $setting->between_ads; ?>

                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12">
                <h5 class="text-mode"><?php echo app('translator')->get('messages.nopost'); ?></h5>
            </div>
            <?php endif; ?>
        </div>
    </div>  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>
<div class="container-fluid mt-auto">
    <hr>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($posts->links()); ?>

        </div>
    </div>
    <footer class="blog-footer">
    <?php if(count($pages) > 0): ?>
        <ul class="list-inline">
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            <li class="list-inline-item">
                <a class="text-mode" href="<?php echo e(url('/page/' . $page->page_slug)); ?>"><?php echo e($page->page_title); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <?php if(!empty($setting->footer)): ?>
    <div class="text-muted"><?php echo clean($setting->footer); ?></div>
    <?php endif; ?>
    </footer>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/popular.blade.php ENDPATH**/ ?>