
<?php $__env->startSection('bodyclass'); ?>
    <body>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jumbotron'); ?>
<div class="jumbotron jblight">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12">
                <h1 class="display-4"><?php echo app('translator')->get('messages.user.edit_profile'); ?></h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container pb-5">
    <div class="row">
        <div class="col-md-8">
            <section class="box-white mt-4 card-shadow">
                <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form method="POST" action="<?php echo e(url('/profile/' . $user->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="mb-3 row">
                        <label for="name" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.sign.name'); ?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="username" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.sign.username'); ?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username); ?>" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="email"  class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.sign.email'); ?></label>
                        <div class="col-sm-9">
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" ><?php echo app('translator')->get('messages.new.cover_image'); ?></label>
                        <div class="col-sm-6">     
                            <input type="file" class="form-control-file" id="cover" name="cover" aria-describedby="fileHelp">
                            <small id="fileHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.new.coverimg_help'); ?></small>
                        </div>
                    </div>
                    <div class="mb-3 row">
                    <label class="col-sm-3 col-form-label" ><?php echo app('translator')->get('messages.sign.user_image'); ?></label>
                        <div class="col-sm-6">     
                            <input type="file" class="form-control-file" id="avatar" name="avatar" aria-describedby="fileHelp">
                            <small id="fileHelp" class="form-text text-muted"><?php echo app('translator')->get('messages.new.img_sizehelp'); ?></small>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="website" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.sign.website'); ?></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="website" name="website" value="<?php echo e($user->website); ?>">
                        </div>
                    </div>
                     <div class="mb-3 row">
                        <label for="facebook" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.new.facebook'); ?></label>
                        <div class="col-sm-9">
                                <input type="text" class="form-control" id="facebook" name="facebook" value="<?php echo e($user->facebook); ?>" placeholder="<?php echo app('translator')->get('messages.login.username'); ?>">                         
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="twitter" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.new.twitter'); ?></label>
                        <div class="col-sm-9">
                                <input type="text" class="form-control" id="twitter" name="twitter" value="<?php echo e($user->twitter); ?>" placeholder="<?php echo app('translator')->get('messages.login.username'); ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="instagram" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.new.instagram'); ?></label>
                        <div class="col-sm-9">
                                <input type="text" class="form-control" id="instagram" name="instagram" value="<?php echo e($user->instagram); ?>" placeholder="<?php echo app('translator')->get('messages.login.username'); ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="linkedin" class="col-sm-3 col-form-label"><?php echo app('translator')->get('messages.new.linkedin'); ?></label>
                        <div class="col-sm-9">
                                <input type="text" class="form-control" id="linkedin" name="linkedin" value="<?php echo e($user->linkedin); ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <div class="offset-sm-4 col-sm-7">
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('messages.save'); ?></button>
                            <a href="<?php echo e(url('/home/')); ?>" class="btn btn-danger" role="button"><?php echo app('translator')->get('messages.cancel'); ?></a> 
                        </div>
                    </div>
                </form>
            </section>
        </div>
            <div class="col-md-4">
            <section class="box-white mt-4 card-shadow">
                <form method="POST" action="<?php echo e(url('/profile/' . $user->id)); ?>" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php echo csrf_field(); ?>
                    <div class="mb-3 row">
                        <label for="password"  class="col-sm-4 col-form-label"><?php echo app('translator')->get('messages.sign.password'); ?></label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="password_confirmation"  class="col-sm-4 col-form-label"><?php echo app('translator')->get('messages.sign.cpassword'); ?></label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <div class="offset-sm-4 col-sm-7">
                            <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('messages.changepass'); ?></button>
                        </div>
                    </div>
                </form>
            </section>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('admin-secret')): ?>
            <section class="box-white mt-4 text-center card-shadow">
                <a class="btn btn-danger" role="button" href="<?php echo e(url('/deleteaccount/')); ?>"><?php echo app('translator')->get('messages.new.userdelete'); ?></a>
            </section>
            <?php endif; ?>
        </div>        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/member/profileedit.blade.php ENDPATH**/ ?>