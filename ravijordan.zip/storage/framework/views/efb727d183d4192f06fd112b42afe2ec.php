<div class="row mb-4">
    <div class="col-lg-6">
        <div class="profile-card">
                <?php if(substr( $user->avatar, 0, 4 ) === "http"): ?>
                <img class="profile-card-photo" src=" <?php echo e($user->avatar); ?> ">
                <?php else: ?>
                <img class="profile-card-photo" src="<?php echo e(url('/images/' . $user->avatar)); ?>">
                <?php endif; ?>
        </div>
        <div class="profile-card pt-5">
            <h1 class="header-title"><?php echo e($user->name); ?></h1>
            <h6>
                <?php echo e($user->username); ?>

                <?php if(isset($user->role)): ?>
                <i class="icon-patch-check-fill text-primary verficon" title="<?php echo app('translator')->get('messages.new.verified'); ?>"></i>
                <?php endif; ?>
                <?php if(isset($user->role)): ?>
                    <span class="text-warning ms-2"><?php echo app('translator')->get($user->role); ?></span>
                <?php endif; ?>
            </h6>
            <h6>
                <?php echo app('translator')->get('messages.user.level'); ?> 
                <span class="badge bg-secondary"><?php echo e(levelNumber($point->sum('likes_count'))); ?></span>
                <span class="ms-2"><?php echo app('translator')->get('messages.user.points'); ?> </span>
                <span class="badge bg-secondary"><?php echo e($point->sum('likes_count')); ?></span>
                <span class="ms-2"><?php echo app('translator')->get('messages.new.totalposts'); ?> </span>
                <span class="badge bg-secondary"><?php echo e(shortNumber($user->posts()->count())); ?></span>
            </h6>
        </div>
    </div>
    <div class="col-lg-4 pt-lg-3">
        <ul class="profile-links-list d-flex justify-content-center">
            <?php if(isset($user->website)): ?>
            <li class="nowrap">
            <a  role="button" class="btn btn-white-shadow" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website" href="<?php echo e($user->website); ?>">
                <i class="icon-globe"></i></a>
            </li>
            <?php endif; ?>
            <?php if(isset($user->facebook)): ?>
            <li class="nowrap">
            <a  role="button" class="btn btn-white-shadow" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facebook" href="https://www.facebook.com/<?php echo e($user->facebook); ?>">
                <i class="icon-facebook"></i></a>
            </li>
            <?php endif; ?>
            <?php if(isset($user->twitter)): ?>
            <li class="nowrap">
            <a  role="button" class="btn btn-white-shadow" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Twitter" href="https://twitter.com/<?php echo e($user->twitter); ?>">
                <i class="icon-twitter"></i></a>
            </li>
            <?php endif; ?>
            <?php if(isset($user->instagram)): ?>
            <li class="nowrap">
            <a  role="button" class="btn btn-white-shadow" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Instagram" href="https://www.instagram.com/<?php echo e($user->instagram); ?>">
                <i class="icon-instagram"></i></a>
            </li>
            <?php endif; ?>
            <?php if(isset($user->linkedin)): ?>
            <li class="nowrap">
            <a  role="button" class="btn btn-white-shadow" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="LinkEdin" href="<?php echo e($user->linkedin); ?>">
                <i class="icon-linkedin"></i></a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="col-lg-2 pt-lg-5 mt-3">
    <?php if(auth()->check()): ?>
        <?php if(auth()->id() == $user->id): ?>
        <div class="d-grid gap-1 col-6 col-lg-12 mx-auto">
            <a href="<?php echo e(url('/profile/' . $user->username . '/edit/')); ?>" role="button" class="btn btn-arrow border-one"><?php echo app('translator')->get('messages.user.edit_profile'); ?></a>
        </div>
        <?php else: ?>
            <?php if(auth()->user()->following($user)): ?>
            <div class="flwid d-grid gap-1 col-6 col-lg-12 mx-auto">
                <input type="hidden" name="follow_id" value="<?php echo e($user->id); ?>">
                <button type="button" class="btn btn-secondary border-one" onclick="follow(this)"><?php echo app('translator')->get('messages.new.unfollow'); ?></button>
            </div>
            <?php else: ?>
            <div class="flwid d-grid gap-1 col-6 col-lg-12 mx-auto">
                <input type="hidden" name="follow_id" value="<?php echo e($user->id); ?>">
                <button type="button" class="btn btn-arrow border-one" onclick="follow(this)"><?php echo app('translator')->get('messages.new.follow'); ?></button>
            </div>                        
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>      
    </div>
</div><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/profilehead.blade.php ENDPATH**/ ?>