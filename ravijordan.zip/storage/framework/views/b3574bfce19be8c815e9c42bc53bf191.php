    <?php if(!empty($post->post_video)): ?>
    <div class="card border-one text-center">            
                <?php if(count($post->tags)): ?>
                <div class="category">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($tag->color); ?>" href="<?php echo e(url('/category/' . $tag->name)); ?>"><?php echo e($tag->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            <div class="bg-over">
            <div class="youtube border-two">
                <span class="play-btn"></span>
                <img class="card-img change-ratio" src="https://i.ytimg.com/vi/<?php echo e($post->post_video); ?>/hqdefault.jpg" alt="video">
            </div>
            <a class="link-over" href="<?php echo e(url('/posts/' . $post->post_slug )); ?>"></a>         
            <div class="card-blog-body">              
                <small class="me-3"><i class="icon-clock me-2"></i> <?php echo e($post->created_at->diffForHumans()); ?></small>
                <small><i class="icon-eye me-2"></i> <?php echo e(shortNumber($post->counter)); ?></small>
                <h4 class="mt-4"><?php echo e(str_limit($post->post_title, 70)); ?></h4>
                <p class="card-text mb-5"><?php echo e(str_limit($post->post_desc, 90)); ?></p>
                <a class="author" href="<?php echo e(url('/profile/' . $post->user->username)); ?>">
                    <?php if(substr( $post->user->avatar, 0, 4 ) === "http"): ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e($post->user->avatar); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php else: ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e(url('/images/' . $post->user->avatar)); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php endif; ?>
                    <div>
                    <?php echo e($post->user->name); ?>

                    </div>
                    <?php if(isset($post->user->role)): ?>
                        <div class="vbadge">
                            <i class="icon-patch-check-fill verficon" title="<?php echo app('translator')->get('messages.new.verified'); ?>"></i>
                        </div>
                    <?php endif; ?>
                </a>
                 <div class="card-like">
                <?php if(auth()->check()): ?>
                    <?php if($post->isLiked): ?>
                        <div class="heart heartliked" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php else: ?>
                        <div class="heart" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(url('/login/')); ?>" >
                        <div class="heartguest"></div>
                    </a>
                <?php endif; ?>
                <div class="card-count" id="likeCount<?php echo e($post->id); ?>"><?php echo e(shortNumber($post->likes()->count())); ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php elseif(!empty($post->post_media)): ?>
        <?php if($post->post_instant == "1"): ?>
        <div class="card border-one text-white text-center bg-card-dark cover" style="background-image: url(<?php echo e(url('/uploads/' . $post->post_media)); ?>);">
            <div class="card-txt-body bg-over">
                <a class="link-over" href="<?php echo e(url('/posts/' . $post->post_slug)); ?>"></a>
                <?php if(count($post->tags)): ?>
                <div class="category">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($tag->color); ?>" href="<?php echo e(url('/category/' . $tag->name)); ?>"><?php echo e($tag->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <small class="me-3"><i class="icon-clock me-2"></i> <?php echo e($post->created_at->diffForHumans()); ?></small>
                <small><i class="icon-eye me-2"></i> <?php echo e(shortNumber($post->counter)); ?></small>
                <h4 class="txt-shad mt-4"><?php echo e(str_limit($post->post_title, 50)); ?></h4>
                <p class="card-text txt-shad mb-5"><?php echo e(str_limit($post->post_desc, 90)); ?></p>
                <a class="author" href="<?php echo e(url('/profile/' . $post->user->username)); ?>">
                    <?php if(substr( $post->user->avatar, 0, 4 ) === "http"): ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e($post->user->avatar); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php else: ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e(url('/images/' . $post->user->avatar)); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php endif; ?>
                    <div>
                    <?php echo e($post->user->name); ?>

                    </div>
                    <?php if(isset($post->user->role)): ?>
                        <div class="vbadge">
                            <i class="icon-patch-check-fill verficon" title="<?php echo app('translator')->get('messages.new.verified'); ?>"></i>
                        </div>
                    <?php endif; ?>
                </a>
                <div class="card-like">
                <?php if(auth()->check()): ?>
                    <?php if($post->isLiked): ?>
                        <div class="heart heartliked" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php else: ?>
                        <div class="heart" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(url('/login/')); ?>" >
                        <div class="heartguest"></div>
                    </a>
                <?php endif; ?>
                <div class="card-count" id="likeCount<?php echo e($post->id); ?>"><?php echo e(shortNumber($post->likes()->count())); ?></div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="card border-one text-center">
                <?php if(count($post->tags)): ?>
                <div class="category">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($tag->color); ?>" href="<?php echo e(url('/category/' . $tag->name)); ?>"><?php echo e($tag->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            <div class="bg-over">
            <img class="card-img border-two" src="<?php echo e(url('/uploads/' . $post->post_media)); ?>" alt="<?php echo e($post->media_alt); ?>">
            <a class="link-over" href="<?php echo e(url('/posts/' . $post->post_slug )); ?>"></a>         
            <div class="card-blog-body">              
                <small class="me-3"><i class="icon-clock me-2"></i> <?php echo e($post->created_at->diffForHumans()); ?></small>
                <small><i class="icon-eye me-2"></i> <?php echo e(shortNumber($post->counter)); ?></small>
                <h4 class="mt-4"><?php echo e(str_limit($post->post_title, 70)); ?></h4>
                <p class="card-text mb-5"><?php echo e(str_limit($post->post_desc, 90)); ?></p>
                <a class="author" href="<?php echo e(url('/profile/' . $post->user->username)); ?>">
                    <?php if(substr( $post->user->avatar, 0, 4 ) === "http"): ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e($post->user->avatar); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php else: ?>
                    <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e(url('/images/' . $post->user->avatar)); ?>" alt="<?php echo e($post->user->username); ?>">
                    <?php endif; ?>
                    <div>
                    <?php echo e($post->user->name); ?>

                    </div>
                    <?php if(isset($post->user->role)): ?>
                        <div class="vbadge">
                            <i class="icon-patch-check-fill verficon" title="<?php echo app('translator')->get('messages.new.verified'); ?>"></i>
                        </div>
                    <?php endif; ?>
                </a>
                 <div class="card-like">
                <?php if(auth()->check()): ?>
                    <?php if($post->isLiked): ?>
                        <div class="heart heartliked" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php else: ?>
                        <div class="heart" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(url('/login/')); ?>" >
                        <div class="heartguest"></div>
                    </a>
                <?php endif; ?>
                <div class="card-count" id="likeCount<?php echo e($post->id); ?>"><?php echo e(shortNumber($post->likes()->count())); ?></div>
                </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php else: ?>
    <div class="card border-one text-white text-center stripes <?php echo e($post->post_color); ?>">
        <div class="card-txt-body bg-over">
            <small class="me-3"><i class="icon-clock me-2"></i> <?php echo e($post->created_at->diffForHumans()); ?></small>
            <small><i class="icon-eye me-2"></i> <?php echo e(shortNumber($post->counter)); ?></small>
            <a class="link-over" href="<?php echo e(url('/posts/' . $post->post_slug)); ?>"></a>
            <div class="card-like">
            <?php if(auth()->check()): ?>
                <?php if($post->isLiked): ?>
                    <div class="heart heartliked" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                <?php else: ?>
                    <div class="heart" onclick="ClickHeart(this)" id="heart<?php echo e($post->id); ?>"></div>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(url('/login/')); ?>" >
                    <div class="heartguest"></div>
                </a>
            <?php endif; ?>
            <div class="card-count" id="likeCount<?php echo e($post->id); ?>"><?php echo e(shortNumber($post->likes()->count())); ?></div>
            </div>
            <?php if(count($post->tags)): ?>
                <div class="category">
                    <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="<?php echo e($tag->color); ?>" href="<?php echo e(url('/category/' . $tag->name)); ?>"><?php echo e($tag->title); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <h4 class="mt-4"><?php echo e(str_limit($post->post_title, 70)); ?></h4>
            <p class="card-text mb-5"><?php echo e(str_limit($post->post_desc, 90)); ?></p>
            <a class="author" href="<?php echo e(url('/profile/' . $post->user->username)); ?>">
                <?php if(substr( $post->user->avatar, 0, 4 ) === "http"): ?>
                <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e($post->user->avatar); ?>" alt="<?php echo e($post->user->username); ?>">
                <?php else: ?>
                <img class="avatar-sm img-fluid rounded-circle" src="<?php echo e(url('/images/' . $post->user->avatar)); ?>" alt="<?php echo e($post->user->username); ?>">
                <?php endif; ?>
                <div>
                <?php echo e($post->user->name); ?>

                </div>            
                <?php if(isset($post->user->role)): ?>
                <div class="vbadge">
                    <i class="icon-patch-check-fill verficon" title="<?php echo app('translator')->get('messages.new.verified'); ?>"></i>
                </div>
                <?php endif; ?>                
            </a>
        </div>
    </div>
    <?php endif; ?>
<?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/public/post.blade.php ENDPATH**/ ?>