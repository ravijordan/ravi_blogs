

<?php $__env->startSection('bodyclass'); ?>
   <body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
  <!-- Example row of columns -->
    <div class="content">
        <div class="alert alert-warning" role="alert">
      		<strong>Nothing was found!</strong> Back to <a href="<?php echo e(url('/')); ?>">Home</a>.
    	</div>
    </div>
  </div> <!-- /container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/errors/404.blade.php ENDPATH**/ ?>