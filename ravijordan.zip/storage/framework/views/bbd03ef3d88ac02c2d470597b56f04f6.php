<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-sidebar sidebar collapse" style="">
  <div class="position-sticky pt-3">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('admin') ? 'active' : ''); ?>" href="<?php echo e(url('/admin')); ?>"><i class="icon-house-door feather"></i><?php echo app('translator')->get('admin.dashboard'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('contents') ? 'active' : ''); ?>" href="<?php echo e(url('/contents')); ?>"><i class="icon-layers feather"></i><?php echo app('translator')->get('admin.posts'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('pages') ? 'active' : ''); ?>" href="<?php echo e(url('/pages')); ?>"><i class="icon-file-earmark feather"></i><?php echo app('translator')->get('admin.pages'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('cats') ? 'active' : ''); ?>" href="<?php echo e(url('/cats')); ?>"><i class="icon-grid feather"></i><?php echo app('translator')->get('admin.categories'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('settings') ? 'active' : ''); ?>" href="<?php echo e(url('/settings')); ?>"><i class="icon-gear feather"></i><?php echo app('translator')->get('admin.settings'); ?></a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin-secret')): ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('adminprofile') ? 'active' : ''); ?>" href="<?php echo e(url('/adminprofile')); ?>"><i class="icon-person feather"></i><?php echo app('translator')->get('admin.profile'); ?></a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('users') ? 'active' : ''); ?>" href="<?php echo e(url('/users')); ?>"><i class="icon-people feather"></i><?php echo app('translator')->get('admin.users'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" target="_blank" href="<?php echo e(url('/')); ?>"><i class="icon-display feather"></i><?php echo app('translator')->get('admin.viewwebsite'); ?></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('/logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"><i class="icon-box-arrow-left feather"></i><?php echo app('translator')->get('admin.logout'); ?></a>
        </li>
        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
        </form>
    </ul>

    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-5 mb-1 text-muted">
      <span>Copyright &copy; <?php echo e(date('Y')); ?> | <a href="https://ravijordan.com" target="_blank" title="Ravi Jordan">Ravi Jordan</a></span>
    </h6>
    
  </div>
</nav><?php /**PATH /home/ravijordan/htdocs/ravijordan.in/resources/views/layouts/adminsidebar.blade.php ENDPATH**/ ?>